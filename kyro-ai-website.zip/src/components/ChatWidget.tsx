import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, X, Sparkles } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { LogoMark } from "./Logo";
import { cn } from "@/lib/utils";

const SUGGESTIONS = [
  "What can Kyro do for my business?",
  "How does pricing work?",
  "Which integrations are supported?",
  "How long does setup take?",
];

export function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({ api: "/api/chat" }),
  });

  const isLoading = status === "submitted" || status === "streaming";

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, status]);

  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 200);
    }
  }, [open, messages.length, status]);

  const handleSend = async (text?: string) => {
    const content = (text ?? input).trim();
    if (!content || isLoading) return;
    setInput("");
    await sendMessage({ text: content });
  };

  return (
    <>
      {/* Floating button */}
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1.2, type: "spring" }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-[60] w-14 h-14 rounded-2xl bg-primary flex items-center justify-center group"
        style={{ boxShadow: "0 0 30px oklch(0.82 0.18 215 / 0.5), 0 8px 24px oklch(0.05 0.01 240 / 0.6)" }}
        aria-label="Open Kyro chat"
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X className="text-primary-foreground" size={22} />
            </motion.div>
          ) : (
            <motion.div key="logo" initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }}>
              <LogoMark size={28} />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: "spring", damping: 25 }}
            className="fixed bottom-24 right-4 sm:right-6 z-[55] w-[calc(100vw-2rem)] sm:w-[400px] h-[600px] max-h-[calc(100vh-7rem)] flex flex-col rounded-3xl glass overflow-hidden"
            style={{ boxShadow: "0 20px 60px oklch(0.05 0.01 240 / 0.8), 0 0 40px oklch(0.82 0.18 215 / 0.15)" }}
          >
            {/* Header */}
            <div className="flex items-center gap-3 px-5 py-4 border-b border-border/40">
              <div className="relative">
                <LogoMark size={32} />
                <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-card animate-pulse" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-display font-semibold text-sm text-foreground">Kyro</h3>
                <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                  <Sparkles size={10} className="text-primary" /> AI Support · Online
                </p>
              </div>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-5 space-y-4">
              {messages.length === 0 && (
                <div className="space-y-4">
                  <div className="text-center py-4">
                    <div className="inline-block mb-3">
                      <LogoMark size={48} />
                    </div>
                    <h4 className="font-display font-semibold text-foreground">Hi, I'm Kyro 👋</h4>
                    <p className="text-xs text-muted-foreground mt-1 px-4">
                      Ask me anything about how AI can transform your customer support.
                    </p>
                  </div>
                  <div className="space-y-2">
                    {SUGGESTIONS.map((s) => (
                      <button
                        key={s}
                        onClick={() => handleSend(s)}
                        className="w-full text-left px-3 py-2.5 text-xs rounded-xl border border-border/60 hover:border-primary/60 hover:bg-primary/5 transition-all text-muted-foreground hover:text-foreground"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {messages.map((m) => {
                const text = m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
                const isUser = m.role === "user";
                return (
                  <div key={m.id} className={cn("flex gap-2", isUser && "justify-end")}>
                    {!isUser && (
                      <div className="flex-shrink-0 mt-1">
                        <LogoMark size={22} />
                      </div>
                    )}
                    <div
                      className={cn(
                        "max-w-[80%] text-sm leading-relaxed",
                        isUser
                          ? "px-4 py-2.5 rounded-2xl rounded-br-md bg-primary text-primary-foreground font-medium"
                          : "text-foreground prose-cyan"
                      )}
                    >
                      {isUser ? (
                        text
                      ) : (
                        <ReactMarkdown
                          components={{
                            p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                            ul: ({ children }) => <ul className="list-disc pl-4 space-y-1 my-2">{children}</ul>,
                            ol: ({ children }) => <ol className="list-decimal pl-4 space-y-1 my-2">{children}</ol>,
                            strong: ({ children }) => <strong className="text-primary font-semibold">{children}</strong>,
                            a: ({ children, href }) => <a href={href} className="text-primary underline">{children}</a>,
                          }}
                        >
                          {text}
                        </ReactMarkdown>
                      )}
                    </div>
                  </div>
                );
              })}

              {status === "submitted" && (
                <div className="flex gap-2 items-center">
                  <LogoMark size={22} />
                  <div className="flex gap-1 px-3 py-2.5 rounded-2xl rounded-bl-md bg-muted/40">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              )}
            </div>

            {/* Composer */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="p-3 border-t border-border/40"
            >
              <div className="flex items-end gap-2 rounded-2xl border border-border bg-input/40 focus-within:border-primary/60 transition-colors p-2">
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder="Ask Kyro anything…"
                  rows={1}
                  className="flex-1 bg-transparent resize-none text-sm text-foreground placeholder:text-muted-foreground outline-none px-2 py-1.5 max-h-32"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || isLoading}
                  className="flex-shrink-0 w-9 h-9 rounded-xl bg-primary text-primary-foreground flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
                >
                  <Send size={14} />
                </button>
              </div>
              <p className="text-[10px] text-muted-foreground/60 text-center mt-2">
                Powered by Kyro AI · This is a live demo
              </p>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
