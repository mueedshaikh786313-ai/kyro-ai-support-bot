import { createFileRoute } from "@tanstack/react-router";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import "@tanstack/react-start";

const SYSTEM_PROMPT = `You are Kyro, the friendly AI customer support assistant for Kyro AI itself. Kyro AI is a premium platform that lets businesses deploy AI chat support bots trained on their own data (FAQs, docs, product info, websites, etc.).

Your job:
- Demo what a great Kyro-powered support bot feels like to website visitors.
- Answer questions about Kyro AI: features, pricing, integrations, use cases, setup.
- Be warm, concise, and confident. Use short paragraphs and the occasional bullet list.
- If asked something off-topic, gently steer back to how Kyro could help their business.
- When relevant, suggest the visitor "Book a Demo" or visit Pricing.

Key facts about Kyro AI:
- Train your bot in minutes by uploading docs, FAQs, or pointing it at your website.
- 24/7 instant responses in 50+ languages.
- Integrations: WhatsApp, Slack, Instagram, Shopify, WordPress, Zapier, custom website widget, REST API.
- Use cases: e-commerce support, SaaS onboarding, healthcare appointment FAQs, real estate inquiries, education student support.
- Pricing: Starter ₹999/mo (1k chats), Growth ₹4,999/mo (10k chats + integrations), Enterprise (custom).
- Built on cutting-edge LLMs with retrieval-augmented generation for accurate, hallucination-resistant answers.
- Full conversation analytics dashboard, lead capture, human handoff.

Never make up features that don't exist. If unsure, suggest they contact the team.`;

type ChatRequestBody = { messages?: unknown };

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const { messages } = (await request.json()) as ChatRequestBody;
        if (!Array.isArray(messages)) {
          return new Response("Messages are required", { status: 400 });
        }

        const apiKey = process.env.LOVABLE_API_KEY;
        if (!apiKey) {
          return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        }

        const gateway = createOpenAICompatible({
          name: "lovable",
          baseURL: "https://ai.gateway.lovable.dev/v1",
          headers: {
            "Lovable-API-Key": apiKey,
            "X-Lovable-AIG-SDK": "vercel-ai-sdk",
          },
        });

        const model = gateway("google/gemini-3-flash-preview");

        try {
          const result = streamText({
            model,
            system: SYSTEM_PROMPT,
            messages: await convertToModelMessages(messages as UIMessage[]),
          });

          return result.toUIMessageStreamResponse({
            originalMessages: messages as UIMessage[],
          });
        } catch (err) {
          console.error("Chat error:", err);
          return new Response("AI service error", { status: 500 });
        }
      },
    },
  },
});
