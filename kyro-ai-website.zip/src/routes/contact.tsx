import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import { Mail, MessageCircle, MapPin, Send, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/contact")({
  component: Contact,
  head: () => ({
    meta: [
      { title: "Contact — Kyro AI" },
      { name: "description", content: "Get in touch with the Kyro AI team. Book a free demo, ask about pricing, or talk integrations." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
});

function Contact() {
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", email: "", company: "", phone: "", message: "" });

  const onChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const { error: err } = await supabase.from("leads").insert({
        name: form.name,
        email: form.email,
        company: form.company || null,
        phone: form.phone || null,
        message: form.message,
      });
      if (err) throw err;
      setSuccess(true);
      setForm({ name: "", email: "", company: "", phone: "", message: "" });
    } catch (err) {
      console.error(err);
      setError("Something went wrong. Please try again or email us directly.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6 pb-20">
      <motion.section
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
        className="text-center py-16"
      >
        <p className="text-xs uppercase tracking-widest text-primary mb-3">Contact</p>
        <h1 className="font-display text-5xl sm:text-6xl md:text-7xl font-semibold tracking-tighter">
          Let's <span className="text-gradient-cyan glow-text">talk.</span>
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto">
          Book a demo, ask a question, or just say hi. We reply within 24 hours.
        </p>
      </motion.section>

      <div className="grid lg:grid-cols-5 gap-8 mt-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}
          className="lg:col-span-2 space-y-4"
        >
          <ContactCard icon={<Mail size={18} />} title="Email" detail="hello@kyroai.com" href="mailto:hello@kyroai.com" />
          <ContactCard icon={<MessageCircle size={18} />} title="WhatsApp" detail="+91 98765 43210" href="https://wa.me/919876543210" />
          <ContactCard icon={<MapPin size={18} />} title="Office" detail="Bengaluru, India" />

          <div className="glass rounded-2xl p-6 mt-6">
            <p className="text-xs uppercase tracking-widest text-primary mb-2">Pro tip</p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Want the fastest answer? Click the floating Kyro chat in the corner — our AI demo bot
              can answer most questions instantly.
            </p>
          </div>
        </motion.div>

        <motion.form
          onSubmit={onSubmit}
          initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}
          className="lg:col-span-3 glass rounded-3xl p-8 space-y-4"
        >
          {success ? (
            <div className="text-center py-12">
              <CheckCircle2 size={48} className="text-primary mx-auto mb-4" />
              <h3 className="font-display text-2xl font-semibold text-foreground mb-2">Got it! 🎉</h3>
              <p className="text-muted-foreground">We'll get back to you within 24 hours.</p>
              <button onClick={() => setSuccess(false)} className="mt-6 text-sm text-primary hover:underline">
                Send another message
              </button>
            </div>
          ) : (
            <>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Name *" name="name" value={form.name} onChange={onChange} required />
                <Field label="Email *" name="email" type="email" value={form.email} onChange={onChange} required />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Company" name="company" value={form.company} onChange={onChange} />
                <Field label="Phone" name="phone" value={form.phone} onChange={onChange} />
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Message *</label>
                <textarea
                  name="message" value={form.message} onChange={onChange} required rows={5}
                  placeholder="Tell us about your business and what you're looking for…"
                  className="w-full px-4 py-3 rounded-xl bg-input/40 border border-border focus:border-primary/60 outline-none text-sm text-foreground placeholder:text-muted-foreground/60 resize-none transition-colors"
                />
              </div>

              {error && (
                <p className="text-sm text-destructive">{error}</p>
              )}

              <button
                type="submit" disabled={submitting}
                className="w-full inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 disabled:opacity-50 transition-all"
                style={{ boxShadow: "0 0 30px oklch(0.82 0.18 215 / 0.3)" }}
              >
                {submitting ? "Sending…" : <>Send message <Send size={14} /></>}
              </button>
            </>
          )}
        </motion.form>
      </div>
    </div>
  );
}

function ContactCard({ icon, title, detail, href }: { icon: React.ReactNode; title: string; detail: string; href?: string }) {
  const Content = (
    <div className="glass rounded-2xl p-5 flex items-center gap-4 hover:border-primary/40 transition-all">
      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
        {icon}
      </div>
      <div>
        <p className="text-xs text-muted-foreground uppercase tracking-wider">{title}</p>
        <p className="font-display font-semibold text-foreground">{detail}</p>
      </div>
    </div>
  );
  return href ? <a href={href}>{Content}</a> : Content;
}

function Field({ label, ...rest }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label className="block text-xs font-medium text-muted-foreground mb-1.5">{label}</label>
      <input
        {...rest}
        className="w-full px-4 py-3 rounded-xl bg-input/40 border border-border focus:border-primary/60 outline-none text-sm text-foreground placeholder:text-muted-foreground/60 transition-colors"
      />
    </div>
  );
}
