import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Check, Sparkles } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/pricing")({
  component: Pricing,
  head: () => ({
    meta: [
      { title: "Pricing — Kyro AI" },
      { name: "description", content: "Simple, transparent pricing for Kyro AI. Start at ₹999/month. 14-day free trial. No credit card required." },
      { property: "og:url", content: "/pricing" },
    ],
    links: [{ rel: "canonical", href: "/pricing" }],
  }),
});

type Plan = {
  name: string;
  tagline: string;
  monthly: number;
  yearly: number;
  features: string[];
  cta: string;
  highlight?: boolean;
  custom?: boolean;
};

const plans: Plan[] = [
  {
    name: "Starter",
    tagline: "For small teams getting started",
    monthly: 999, yearly: 9990,
    features: ["1,000 conversations / month", "1 trained agent", "Website widget", "Email support", "Basic analytics", "10 data sources"],
    cta: "Start Free Trial",
  },
  {
    name: "Growth",
    tagline: "For growing businesses",
    monthly: 4999, yearly: 49990,
    features: ["10,000 conversations / month", "3 trained agents", "All integrations (WhatsApp, Slack, etc.)", "Priority support", "Advanced analytics & exports", "Unlimited data sources", "Lead capture & CRM sync", "Human handoff", "Custom branding"],
    cta: "Start Free Trial",
    highlight: true,
  },
  {
    name: "Enterprise",
    tagline: "For scale and custom needs",
    monthly: 0, yearly: 0,
    features: ["Unlimited conversations", "Unlimited agents", "All integrations + custom", "Dedicated success manager", "SSO & advanced security", "SLA & 24/7 priority support", "Custom AI model fine-tuning", "On-premise deployment"],
    cta: "Talk to Sales",
    custom: true,
  },
];

const faqs = [
  { q: "Is there a free trial?", a: "Yes — every plan starts with a 14-day free trial. No credit card required." },
  { q: "What counts as a conversation?", a: "A conversation is a unique chat session with one customer. Multiple messages in one session = one conversation." },
  { q: "Can I switch plans later?", a: "Anytime. Upgrade or downgrade from your dashboard — prorated billing applies." },
  { q: "How long does setup take?", a: "Most customers go live in under an hour. Upload your data, customize your agent, deploy." },
  { q: "Is my data secure?", a: "Yes. AES-256 encryption at rest, TLS in transit, and your data is never used to train external models." },
];

function Pricing() {
  const [yearly, setYearly] = useState(false);

  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6 pb-20">
      <motion.section
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
        className="text-center py-16"
      >
        <p className="text-xs uppercase tracking-widest text-primary mb-3">Pricing</p>
        <h1 className="font-display text-5xl sm:text-6xl md:text-7xl font-semibold tracking-tighter">
          Simple <span className="text-gradient-cyan glow-text">pricing.</span>
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
          14-day free trial on every plan. Cancel anytime.
        </p>

        <div className="mt-10 inline-flex items-center gap-1 p-1 rounded-full glass">
          <button onClick={() => setYearly(false)}
            className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${!yearly ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
            Monthly
          </button>
          <button onClick={() => setYearly(true)}
            className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${yearly ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
            Yearly <span className="text-xs ml-1 opacity-70">save 17%</span>
          </button>
        </div>
      </motion.section>

      <div className="grid md:grid-cols-3 gap-5">
        {plans.map((p, i) => (
          <motion.div
            key={p.name}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.08 }}
            className={`relative rounded-3xl p-8 ${p.highlight ? "glass border-primary/60" : "glass"}`}
            style={p.highlight ? { boxShadow: "0 0 40px oklch(0.82 0.18 215 / 0.2)" } : undefined}
          >
            {p.highlight && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-semibold flex items-center gap-1">
                <Sparkles size={11} /> Most Popular
              </div>
            )}
            <h3 className="font-display text-2xl font-semibold text-foreground">{p.name}</h3>
            <p className="text-sm text-muted-foreground mt-1">{p.tagline}</p>

            <div className="mt-6 mb-6">
              {p.custom ? (
                <p className="font-display text-4xl font-semibold text-foreground">Custom</p>
              ) : (
                <div className="flex items-baseline gap-1">
                  <span className="font-display text-5xl font-semibold text-foreground">
                    ₹{(yearly ? p.yearly / 12 : p.monthly).toLocaleString("en-IN")}
                  </span>
                  <span className="text-sm text-muted-foreground">/mo</span>
                </div>
              )}
              {!p.custom && yearly && (
                <p className="text-xs text-primary mt-1">Billed ₹{p.yearly.toLocaleString("en-IN")}/year</p>
              )}
            </div>

            <Link to="/contact"
              className={`block text-center py-3 rounded-xl text-sm font-semibold transition-all ${
                p.highlight
                  ? "bg-primary text-primary-foreground hover:opacity-90"
                  : "glass text-foreground hover:border-primary/60"
              }`}>
              {p.cta}
            </Link>

            <ul className="mt-6 space-y-3">
              {p.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm text-foreground">
                  <Check size={16} className="text-primary flex-shrink-0 mt-0.5" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>

      <section className="mt-24">
        <motion.h2
          initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          className="font-display text-3xl sm:text-4xl font-semibold text-center mb-10">
          Frequently asked questions
        </motion.h2>
        <div className="max-w-2xl mx-auto space-y-3">
          {faqs.map((f, i) => (
            <motion.details
              key={f.q}
              initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="group glass rounded-xl p-5 cursor-pointer"
            >
              <summary className="font-display font-semibold text-foreground list-none flex justify-between items-center">
                {f.q}
                <span className="text-primary text-xl group-open:rotate-45 transition-transform">+</span>
              </summary>
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{f.a}</p>
            </motion.details>
          ))}
        </div>
      </section>
    </div>
  );
}
